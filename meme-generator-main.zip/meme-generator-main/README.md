This project was bootstrapped with React and Bootstrap.

## Available Scripts

In the project directory, you can run:

### `npm start`

Runs the app in the development mode.<br>
Open [http://localhost:3000](http://localhost:3000) to view it in the browser.

## Learn More

This is a fun 5 hour project inspired by imgur. Built with React and Bootstrap.

You can add top and bottom text to a meme-template, move the text around and can save the image by downloading it.
